import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import Card from "@material-ui/core/Card";
import CardActionArea from "@material-ui/core/CardActionArea";
import CardActions from "@material-ui/core/CardActions";
import CardContent from "@material-ui/core/CardContent";
import CardMedia from "@material-ui/core/CardMedia";
import Button from "@material-ui/core/Button";
import Typography from "@material-ui/core/Typography";
//import { AppBar, Box, IconButton, Link } from "@material-ui/core";
import logo from "../p1.jpg";
import logo1 from "../p2.jpg";
import logo2 from "../p3.jpg";
import logo3 from "../p4.jpg";
import { Grid } from "@material-ui/core";
import { Link } from "react-router-dom";
import { useHistory } from "react-router-dom";
import Hidden from "@material-ui/core/Hidden";

const useStyles = makeStyles((theme) => ({
  root: {
    flexGrow: 1,
    margin: 25,
  },

  Media: {
    width: "150px",
    height: "150px",
    display: "flex",
    justifyContent: "center",
  },
  card: {
    // padding: theme.spacing(2),
    textAlign: "center",
  },
  container: {
    display: "flex",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
  },
}));

export default function Responcard1() {
  const classes = useStyles();
  const { push } = useHistory();

  return (
    <div>
      <div style={{ margin: "15px", padding: "5px", textAlign: "center" }}>
        {" "}
        <h3> Latest Mobiles Phone </h3>
      </div>

      <Grid class="carding">
        <Grid>
          <Card className={classes.root}>
            <CardActionArea>
              <div
                style={{
                  marginTop: "10px",
                  display: "flex",
                  justifyContent: "center",
                }}
              >
                <CardMedia
                  className={classes.Media}
                  component="img"
                  justifyContent="center"
                  alt="Contemplative Reptile"
                  //height="70"
                  img
                  src={logo}
                  title="Contemplative Reptile"
                />
              </div>
              <CardContent className={classes.card}>
                <Typography gutterBottom variant="h5" component="h2">
                  Xiaomi Redmi Note 10S
                </Typography>
                <Typography variant="body2" color="textSecondary" component="p">
                  Rs. 66,900 OFF
                </Typography>
                <Button
                  variant="contained"
                  color="primary"
                  component={Link}
                  onClick={() => push("/products")}
                  //justify="right"
                >
                  Shop Now
                </Button>
              </CardContent>
            </CardActionArea>
          </Card>
        </Grid>

        <Grid>
          <Card className={classes.root}>
            <CardActionArea>
              <div
                style={{
                  marginTop: "10px",
                  display: "flex",
                  justifyContent: "center",
                }}
              >
                <CardMedia
                  className={classes.Media}
                  component="img"
                  justifyContent="center"
                  alt="Contemplative Reptile"
                  //height="70"
                  img
                  src={logo1}
                  title="Contemplative Reptile"
                />
              </div>
              <CardContent className={classes.card}>
                <Typography gutterBottom variant="h5" component="h2">
                  Xiaomi Redmi Note 10
                </Typography>
                <Typography variant="body2" color="textSecondary" component="p">
                  Rs. 15,900 OFF
                </Typography>
                <Button
                  variant="contained"
                  color="primary"
                  component={Link}
                  onClick={() => push("/products")}
                  //justify="right"
                >
                  Shop Now
                </Button>
              </CardContent>
            </CardActionArea>
          </Card>
        </Grid>
        <Grid>
          <Card className={classes.root}>
            <CardActionArea>
              <div
                style={{
                  marginTop: "10px",
                  display: "flex",
                  justifyContent: "center",
                }}
              >
                <CardMedia
                  className={classes.Media}
                  component="img"
                  justifyContent="center"
                  alt="Contemplative Reptile"
                  //height="70"
                  img
                  src={logo3}
                  title="Contemplative Reptile"
                />
              </div>
              <CardContent className={classes.card}>
                <Typography gutterBottom variant="h5" component="h2">
                  Samsung Galaxy A52 PRO
                </Typography>
                <Typography variant="body2" color="textSecondary" component="p">
                  Rs. 15,900 OFF
                </Typography>
                <Button
                  variant="contained"
                  color="primary"
                  component={Link}
                  onClick={() => push("/products")}
                  //justify="right"
                >
                  Shop Now
                </Button>
              </CardContent>
            </CardActionArea>
          </Card>
        </Grid>
        <Grid>
          <Card className={classes.root}>
            <CardActionArea>
              <div
                style={{
                  marginTop: "10px",
                  display: "flex",
                  justifyContent: "center",
                }}
              >
                <CardMedia
                  className={classes.Media}
                  component="img"
                  justifyContent="center"
                  alt="Contemplative Reptile"
                  //height="70"
                  img
                  src={logo2}
                  title="Contemplative Reptile"
                />
              </div>
              <CardContent className={classes.card}>
                <Typography gutterBottom variant="h5" component="h2">
                  Xiaomi Poco 11 Lite
                </Typography>
                <Typography variant="body2" color="textSecondary" component="p">
                  Rs. 56,900 OFF
                </Typography>
                <Button
                  variant="contained"
                  color="primary"
                  component={Link}
                  onClick={() => push("/products")}
                  //justify="right"
                >
                  Shop Now
                </Button>
              </CardContent>
            </CardActionArea>
          </Card>
        </Grid>
      </Grid>

      <div style={{ padding: "20px", textAlign: "center" }}>
        {" "}
        <h3> Get Your All Latest Mobiles Phone Set here </h3>
        <Button
          style={{ margin: "5px", padding: "10px", textAlign: "center" }}
          variant="contained"
          color="primary"
          component={Link}
          onClick={() => push("/products")}
          //justify="right"
        >
          View All Latest Mobiles Phone Here
        </Button>
      </div>
    </div>
  );
}
