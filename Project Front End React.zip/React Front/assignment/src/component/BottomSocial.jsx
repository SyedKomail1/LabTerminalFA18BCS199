import React from "react";
import { withStyles } from "@material-ui/core/styles";
import { green } from "@material-ui/core/colors";
import FormGroup from "@material-ui/core/FormGroup";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import Checkbox from "@material-ui/core/Checkbox";
import CheckBoxOutlineBlankIcon from "@material-ui/icons/CheckBoxOutlineBlank";
import CheckBoxIcon from "@material-ui/icons/CheckBox";
import Favorite from "@material-ui/icons/Favorite";
import FavoriteBorder from "@material-ui/icons/FavoriteBorder";
import { Grid, Box, IconButton, Link } from "@material-ui/core";
import Paper from "@material-ui/core/Paper";

const GreenCheckbox = withStyles({
  root: {
    alignItems: "center",
    color: green[400],
    "&$checked": {
      color: green[600],
      textAlign: "center",
    },
    root1: {
      alignItems: "center",
    },
  },
  checked: {},
})((props) => <Checkbox color="default" {...props} />);

export default function CheckboxLabels() {
  const [state, setState] = React.useState({
    checkedA: true,
    checkedB: true,
    checkedF: true,
    checkedG: true,
  });

  const handleChange = (event) => {
    setState({ ...state, [event.target.name]: event.target.checked });
  };
  const classes = withStyles();

  return (
    <Box
      //display="flex"
      //height="10"
      //width={80}
      // padding="10"
      //margin="10"
      bgcolor="white"
      //alignItems="center"
      justifyContent="center"
      textAlign="center"
      color="theme.palette.text.secondary"
    >
      <Grid container spacing={3}></Grid>
      <Grid container spacing={3}>
        <Grid item xs>
          <Paper className={classes.paper}></Paper>
        </Grid>
        <Grid item xs={6}>
          <FormGroup col className={classes.root}>
            <h1>We are here to help you out</h1>

            <FormControlLabel
              control={
                <Checkbox
                  checked={state.checkedA}
                  onChange={handleChange}
                  name="checkedA"
                />
              }
              label="Have you like our FB Page FB/oyemobile? Like our Page to get latest updates"
            />
            <FormControlLabel
              control={
                <Checkbox
                  checked={state.checkedF}
                  onChange={handleChange}
                  name="checkedF"
                  indeterminate
                />
              }
              label="Did you Follow our instagram Page IG/oyemobile We share latest products updates"
            />
            <FormControlLabel
              control={
                <GreenCheckbox
                  checked={state.checkedG}
                  onChange={handleChange}
                  name="checkedG"
                />
              }
              label="Did you Follow our Channel on Tik Tok  Page TickTok/oyemobile, we do competitions on daily basis"
            />
            <FormControlLabel
              control={
                <Checkbox
                  icon={<FavoriteBorder />}
                  checkedIcon={<Favorite />}
                  name="checkedH"
                />
              }
              label="Any Issues, contact our customer support, Avialable 24/7 to help you out and solve your queries"
            />
          </FormGroup>
        </Grid>
        <Grid item xs>
          <Paper className={classes.paper}></Paper>
        </Grid>
      </Grid>
      <Box component="span" m={1}></Box>
    </Box>
  );
}
