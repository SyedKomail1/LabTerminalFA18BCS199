import React from "react";
import { Link } from "react-router-dom";

import { makeStyles } from "@material-ui/core/styles";
import {
  AppBar,
  Toolbar,
  Typography,
  Button,
  IconButton,
  List,
  ListItem,
  ListItemText,
  Divider,
  Drawer,
  fade,
  InputBase,
} from "@material-ui/core";
import userService from "./services/UserService";
import MenuIcon from "@material-ui/icons/Menu";
import SearchIcon from "@material-ui/icons/Search";
import logo from "../Logo1.png";

const useStyles = makeStyles((theme) => ({
  root: {
    flexGrow: 1,
  },

  menuButton: {
    marginRight: theme.spacing(100),
  },
  title: {
    // flexGrow: 1,
    display: "none",
    [theme.breakpoints.up("sm")]: {
      display: "block",
      // justifyContent: "flex-start",
    },
  },
  search: {
    position: "relative",
    borderRadius: theme.shape.borderRadius,
    backgroundColor: fade(theme.palette.common.white, 0.15),
    "&:hover": {
      backgroundColor: fade(theme.palette.common.white, 0.25),
    },
    marginLeft: 0,
    width: "100%",
    [theme.breakpoints.up("sm")]: {
      marginLeft: theme.spacing(1),
      width: "auto",
      // justifyContent: "flex-end",
    },
  },
  searchIcon: {
    padding: theme.spacing(0, 2),
    height: "100%",
    position: "absolute",
    pointerEvents: "none",

    alignItems: "center",
    display: "flex",
  },
  inputRoot: {
    color: "inherit",
  },
  inputInput: {
    padding: theme.spacing(1, 1, 1, 0),
    // vertical padding + font size from searchIcon
    paddingLeft: `calc(1em + ${theme.spacing(4)}px)`,
    transition: theme.transitions.create("width"),
    width: "100%",
    [theme.breakpoints.up("sm")]: {
      width: "12ch",
      "&:focus": {
        width: "20ch",
      },
    },
  },
  list: {
    width: 250,
  },
  fullList: {
    width: "auto",
  },
  link: {
    color: "orange",
    paddingRight: "1rem",
  },
  link1: {
    color: "green",
    paddingRight: "1rem",
  },
  logo: {
    maxWidth: 100,
    marginRight: "10px",
  },
}));

//export default function SearchAppBar() {
const TopMenu = () => {
  const [state, setState] = React.useState(false);

  const toggleDrawer = (open) => (event) => {
    setState(open);
  };
  const list = () => (
    <div onClick={toggleDrawer(false)}>
      <List>
        <ListItem button component="a" href="/">
          <ListItemText primary="Home" />
        </ListItem>
      </List>
      <Divider />
      <List>
        <ListItem button component="a" href="/products">
          <ListItemText primary="Products" />
        </ListItem>
      </List>

      <Divider />
      <List>
        <ListItem button component="a" href="/contactus">
          <ListItemText primary="Contactus" />
        </ListItem>
      </List>
      {!userService.isLoggedIn() ? (
        <>
          <List>
            <ListItem button component="a" href="/login">
              <ListItemText primary="Login" />
            </ListItem>
          </List>

          <List>
            <ListItem button component="a" href="/register">
              <ListItemText primary="Register" />
            </ListItem>
          </List>
        </>
      ) : (
        <Button
          variant="contained"
          color="primary"
          onClick={(e) => {
            userService.logout();
            window.location.reload();
          }}
        >
          LogOut {userService.getLoggedInUser().name}
        </Button>
      )}
    </div>
  );

  const classes = useStyles();
  return (
    <AppBar
      style={{ backgroundColor: "black", height: "80px" }}
      position="static"
    >
      <Toolbar>
        <IconButton
          color="primary"
          aria-label="open drawer"
          edge="start"
          onClick={toggleDrawer(true)}
          component="span"
        >
          <MenuIcon />
        </IconButton>
        <Drawer anchor={"left"} open={state} onClose={toggleDrawer(false)}>
          {list()}
        </Drawer>
        <img src={logo} alt="Papa oye" className={classes.logo} />
        <Typography variant="h6">
          <Link to="/" className={classes.link}>
            OyeMobile
          </Link>
        </Typography>
        <Typography variant="h6">
          <Link to="/" className={classes.link1}>
            Home
          </Link>
        </Typography>

        <Typography variant="h6">
          <Link to="/products" className={classes.link1}>
            Products
          </Link>
        </Typography>

        <Typography variant="h6">
          <Link to="/contactus" className={classes.link1}>
            Contact Us
          </Link>
        </Typography>

        {!userService.isLoggedIn() ? (
          <>
            <Typography variant="h6">
              <Link to="/login" className={classes.link1}>
                Login
              </Link>
            </Typography>
            <Typography variant="h6">
              <Link to="/register" className={classes.link1}>
                Register
              </Link>
            </Typography>
          </>
        ) : (
          <Button
            variant="contained"
            color="primary"
            onClick={(e) => {
              userService.logout();
              window.location.reload();
            }}
          >
            LogOut {userService.getLoggedInUser().name}
          </Button>
        )}

        <div className={classes.search}>
          <div className={classes.searchIcon}>
            <SearchIcon />
          </div>
          <InputBase
            placeholder="Search…"
            classes={{
              root: classes.inputRoot,
              input: classes.inputInput,
            }}
            inputProps={{ "aria-label": "search" }}
          />
        </div>
      </Toolbar>
    </AppBar>
  );
};

export default TopMenu;
