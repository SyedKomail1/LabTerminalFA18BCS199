import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import Card from "@material-ui/core/Card";
import CardActionArea from "@material-ui/core/CardActionArea";
import CardActions from "@material-ui/core/CardActions";
import CardContent from "@material-ui/core/CardContent";
import CardMedia from "@material-ui/core/CardMedia";
import Button from "@material-ui/core/Button";
import Typography from "@material-ui/core/Typography";
//import { AppBar, Box, IconButton, Link } from "@material-ui/core";
import logo from "../a1 (1).jpg";
import logo1 from "../a1 (5).jpg";
import logo2 from "../a1 (3).jpg";
import logo3 from "../a1 (4).jpg";
import { Grid } from "@material-ui/core";
import { Link } from "react-router-dom";
import { useHistory } from "react-router-dom";
import Hidden from "@material-ui/core/Hidden";

const useStyles = makeStyles((theme) => ({
  root: {
    flexGrow: 1,
    margin: 25,
  },

  Media: {
    width: "150px",
    height: "150px",
    display: "flex",
    justifyContent: "center",
  },
  card: {
    // padding: theme.spacing(2),
    textAlign: "center",
  },
  container: {
    display: "flex",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
  },
}));

export default function ResponCard() {
  const classes = useStyles();
  const { push } = useHistory();

  return (
    <div>
      <div style={{ margin: "15px", padding: "5px", textAlign: "center" }}>
        {" "}
        <h3> Latest TV </h3>
      </div>

      <Grid class="carding">
        <Grid>
          <Card className={classes.root}>
            <CardActionArea>
              <div
                style={{
                  marginTop: "10px",
                  display: "flex",
                  justifyContent: "center",
                }}
              >
                <CardMedia
                  className={classes.Media}
                  component="img"
                  justifyContent="center"
                  alt="Contemplative Reptile"
                  //height="70"
                  img
                  src={logo}
                  title="Contemplative Reptile"
                />
              </div>
              <CardContent className={classes.card}>
                <Typography gutterBottom variant="h5" component="h2">
                  TCL 49 Inch FHD Smart
                </Typography>
                <Typography variant="body2" color="textSecondary" component="p">
                  Rs. 66,900 OFF
                </Typography>
                <Button
                  variant="contained"
                  color="primary"
                  component={Link}
                  onClick={() => push("/products")}
                  //justify="right"
                >
                  Shop Now
                </Button>
              </CardContent>
            </CardActionArea>
          </Card>
        </Grid>

        <Grid>
          <Card className={classes.root}>
            <CardActionArea>
              <div
                style={{
                  marginTop: "10px",
                  display: "flex",
                  justifyContent: "center",
                }}
              >
                <CardMedia
                  className={classes.Media}
                  component="img"
                  justifyContent="center"
                  alt="Contemplative Reptile"
                  //height="70"
                  img
                  src={logo1}
                  title="Contemplative Reptile"
                />
              </div>
              <CardContent className={classes.card}>
                <Typography gutterBottom variant="h5" component="h2">
                  TCL 32 Inch FHD Smart
                </Typography>
                <Typography variant="body2" color="textSecondary" component="p">
                  Rs. 15,900 OFF
                </Typography>
                <Button
                  variant="contained"
                  color="primary"
                  component={Link}
                  onClick={() => push("/products")}
                  //justify="right"
                >
                  Shop Now
                </Button>
              </CardContent>
            </CardActionArea>
          </Card>
        </Grid>
        <Grid>
          <Card className={classes.root}>
            <CardActionArea>
              <div
                style={{
                  marginTop: "10px",
                  display: "flex",
                  justifyContent: "center",
                }}
              >
                <CardMedia
                  className={classes.Media}
                  component="img"
                  justifyContent="center"
                  alt="Contemplative Reptile"
                  //height="70"
                  img
                  src={logo3}
                  title="Contemplative Reptile"
                />
              </div>
              <CardContent className={classes.card}>
                <Typography gutterBottom variant="h5" component="h2">
                  TCL 56 Inch FHD Smart
                </Typography>
                <Typography variant="body2" color="textSecondary" component="p">
                  Rs. 15,900 OFF
                </Typography>
                <Button
                  variant="contained"
                  color="primary"
                  component={Link}
                  onClick={() => push("/products")}
                  //justify="right"
                >
                  Shop Now
                </Button>
              </CardContent>
            </CardActionArea>
          </Card>
        </Grid>
        <Grid>
          <Card className={classes.root}>
            <CardActionArea>
              <div
                style={{
                  marginTop: "10px",
                  display: "flex",
                  justifyContent: "center",
                }}
              >
                <CardMedia
                  className={classes.Media}
                  component="img"
                  justifyContent="center"
                  alt="Contemplative Reptile"
                  //height="70"
                  img
                  src={logo2}
                  title="Contemplative Reptile"
                />
              </div>
              <CardContent className={classes.card}>
                <Typography gutterBottom variant="h5" component="h2">
                  TCL 50 Inch 4K UHD
                </Typography>
                <Typography variant="body2" color="textSecondary" component="p">
                  Rs. 56,900 OFF
                </Typography>
                <Button
                  variant="contained"
                  color="primary"
                  component={Link}
                  onClick={() => push("/products")}
                  //justify="right"
                >
                  Shop Now
                </Button>
              </CardContent>
            </CardActionArea>
          </Card>
        </Grid>
      </Grid>

      <div style={{ padding: "20px", textAlign: "center" }}>
        {" "}
        <h3> Get Your Television Set here </h3>
        <Button
          style={{ margin: "5px", padding: "10px", textAlign: "center" }}
          variant="contained"
          color="primary"
          component={Link}
          onClick={() => push("/products")}
          //justify="right"
        >
          View All Latest HD Televisions
        </Button>
      </div>
    </div>
  );
}
