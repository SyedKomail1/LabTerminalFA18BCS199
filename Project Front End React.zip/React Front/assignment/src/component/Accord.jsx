import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import Accordion from "@material-ui/core/Accordion";
import AccordionSummary from "@material-ui/core/AccordionSummary";
import AccordionDetails from "@material-ui/core/AccordionDetails";
import Typography from "@material-ui/core/Typography";
import ExpandMoreIcon from "@material-ui/icons/ExpandMore";

const useStyles = makeStyles((theme) => ({
  root: {
    width: "100%",
  },
  heading: {
    fontSize: theme.typography.pxToRem(15),
    fontWeight: theme.typography.fontWeightRegular,
  },
}));

export default function SimpleAccordion() {
  const classes = useStyles();

  return (
    <div
      className={classes.root}
      style={{ marginTop: "8px", marginBottom: "8px", marginLeft: "8px" }}
    >
      <h2> Latest Hot Sale Mobiles </h2>
      <Accordion>
        <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel1a-content"
          id="panel1a-header"
        >
          <Typography className={classes.heading}>
            {" "}
            Huawei Nova 7i's 10,000 Sales Today{" "}
          </Typography>
        </AccordionSummary>
        <AccordionDetails>
          <Typography>
            Huawei Nova 7i's lowest price in Pakistan is Rs.39,099. The online
            store PriceOye offers the best price for this Huawei Mobile when
            compared among 1 sellers.
          </Typography>
        </AccordionDetails>
      </Accordion>
      <Accordion>
        <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel2a-content"
          id="panel2a-header"
        >
          <Typography className={classes.heading}>
            {" "}
            Huawei Nova 6i's 9,000 Sales Today
          </Typography>
        </AccordionSummary>
        <AccordionDetails>
          <Typography>
            Huawei Nova 6i's lowest price in Pakistan is Rs.39,099. The online
            store PriceOye offers the best price for this Huawei Mobile when
            compared among 1 sellers.
          </Typography>
        </AccordionDetails>
      </Accordion>
      <Accordion disabled>
        <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel3a-content"
          id="panel3a-header"
        >
          <Typography className={classes.heading}>
            Huawei Nova 5i's 9,000 Sales - No Set Available - Sale out Now
          </Typography>
        </AccordionSummary>
      </Accordion>
    </div>
  );
}
