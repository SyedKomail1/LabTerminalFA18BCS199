import React, { Component } from "react";
import PropTypes from "prop-types";
import ShoppingCartIcon from "@material-ui/icons/ShoppingCart";
import ShoppingBasketSharpIcon from "@material-ui/icons/ShoppingBasketSharp";
import ContactMailSharpIcon from "@material-ui/icons/ContactMailSharp";
import LockOpenIcon from "@material-ui/icons/LockOpen";
import VpnKeyIcon from "@material-ui/icons/VpnKey";
import {
  AppBar,
  Toolbar,
  Typography,
  List,
  ListItem,
  withStyles,
  Grid,
  IconButton,
  SwipeableDrawer,
} from "@material-ui/core";
import MenuIcon from "@material-ui/icons/Menu";
import userService from "./services/UserService";
import { Link } from "react-router-dom";

import { makeStyles } from "@material-ui/core/styles";
import logo from "../Logo13.png";
import { Button } from "@material-ui/core";

const styleSheet = {
  list: {
    width: 200,
  },
  padding: {
    paddingRight: 30,
    cursor: "pointer",
  },

  sideBarIcon: {
    padding: 0,
    color: "white",
    cursor: "pointer",
  },
  app: {
    backgroundColor: "black",
  },
  link: {
    color: "white",
  },
};

class ResAppBar extends Component {
  constructor(props) {
    super(props);
    this.state = { drawerActivate: false, drawer: false };
    this.createDrawer = this.createDrawer.bind(this);
    this.destroyDrawer = this.destroyDrawer.bind(this);
  }

  componentWillMount() {
    if (window.innerWidth <= 600) {
      this.setState({ drawerActivate: true });
    }

    window.addEventListener("resize", () => {
      if (window.innerWidth <= 600) {
        this.setState({ drawerActivate: true });
      } else {
        this.setState({ drawerActivate: false });
      }
    });
  }

  //Small Screens
  createDrawer() {
    const { classes } = this.props;
    return (
      <div>
        <AppBar
          className={this.props.classes.app}
          style={{
            backgroundColor: "black",
            height: "60px",
            marginBottom: "50px",
          }}
        >
          <Toolbar>
            <Grid
              container
              direction="row"
              justify="space-between"
              alignItems="center"
            >
              <MenuIcon
                className={this.props.classes.sideBarIcon}
                onClick={() => {
                  this.setState({ drawer: true });
                }}
              />

              <Typography
                variant="subheading"
                color="inherit"
                className={classes.padding}
              >
                <Link
                  to="/"
                  className={classes.link}
                  style={{ textDecoration: "none" }}
                >
                  <h4> Oye Mobile</h4>
                </Link>
              </Typography>
              <Typography variant="headline"></Typography>
            </Grid>
          </Toolbar>
        </AppBar>

        <SwipeableDrawer
          open={this.state.drawer}
          onClose={() => {
            this.setState({ drawer: false });
          }}
          onOpen={() => {
            this.setState({ drawer: true });
          }}
        >
          <div
            tabIndex={0}
            role="button"
            onClick={() => {
              this.setState({ drawer: false });
            }}
            onKeyDown={() => {
              this.setState({ drawer: false });
            }}
          >
            <List className={this.props.classes.list}>
              <ListItem key={2} button divider>
                {" "}
                <Typography variant="h6">
                  <Link to="/" style={{ textDecoration: "none" }}>
                    Home
                  </Link>
                </Typography>{" "}
              </ListItem>
              <ListItem key={3} button divider>
                {" "}
                <Typography variant="h6">
                  <Link to="/products" style={{ textDecoration: "none" }}>
                    Products
                  </Link>
                </Typography>{" "}
              </ListItem>
              <ListItem key={3} button divider>
                {" "}
                <Typography variant="h6">
                  <Link to="/cart" style={{ textDecoration: "none" }}>
                    Cart
                  </Link>
                </Typography>{" "}
              </ListItem>
              <ListItem key={3} button divider>
                {" "}
                <Typography variant="h6">
                  <Link to="/contactus" style={{ textDecoration: "none" }}>
                    Contact Us
                  </Link>
                </Typography>{" "}
              </ListItem>
              {!userService.isLoggedIn() ? (
                <>
                  <ListItem key={1} button divider>
                    <Typography variant="h6">
                      <Link to="/login" style={{ textDecoration: "none" }}>
                        Login
                      </Link>
                    </Typography>
                  </ListItem>
                  <ListItem key={2} button divider>
                    {" "}
                    <Typography variant="h6">
                      <Link to="/register" style={{ textDecoration: "none" }}>
                        Register
                      </Link>
                    </Typography>{" "}
                  </ListItem>
                </>
              ) : (
                <Button
                  variant="contained"
                  color="primary"
                  onClick={(e) => {
                    userService.logout();
                    window.location.reload();
                  }}
                >
                  LogOut {userService.getLoggedInUser().name}
                </Button>
              )}{" "}
            </List>
          </div>
        </SwipeableDrawer>
      </div>
    );
  }

  //Larger Screens
  destroyDrawer() {
    const { classes } = this.props;
    return (
      <AppBar style={{ backgroundColor: "black" }}>
        <Toolbar>
          <div>
            <Link to="/" style={{ textDecoration: "none" }}>
              <img src={logo} alt="Papa oye" style={{ width: "300px" }} />
            </Link>
          </div>

          <Typography
            variant="headline"
            style={{ flexGrow: 1 }}
            color="inherit"
          ></Typography>
          <IconButton
            style={{ marginBottom: "10px", marginRight: "0px" }}
            color="primary"
            aria-label="upload picture"
            component="span"
          >
            <Link
              to="/products"
              className={classes.link}
              style={{ textDecoration: "none" }}
            >
              <h1>
                {" "}
                <ShoppingBasketSharpIcon />
              </h1>
            </Link>
          </IconButton>

          <Typography
            variant="subheading"
            color="inherit"
            className={classes.padding}
          >
            <Link
              to="/products"
              className={classes.link}
              style={{ textDecoration: "none" }}
            >
              <h4> Products </h4>
            </Link>
          </Typography>

          <IconButton
            style={{ marginBottom: "10px", marginRight: "-2px" }}
            color="primary"
            aria-label="upload picture"
            component="span"
          >
            <Link
              to="/cart"
              className={classes.link}
              style={{ textDecoration: "none" }}
            >
              <h1>
                {" "}
                <ShoppingCartIcon />
              </h1>
            </Link>
          </IconButton>

          <Typography
            variant="subheading"
            color="inherit"
            className={classes.padding}
          >
            <Link
              to="/cart"
              className={classes.link}
              style={{ textDecoration: "none" }}
            >
              <h4> Cart </h4>
            </Link>
          </Typography>
          <IconButton
            style={{ marginBottom: "10px", marginRight: "-2px" }}
            color="primary"
            aria-label="upload picture"
            component="span"
          >
            <Link
              to="/contactus"
              className={classes.link}
              style={{ textDecoration: "none" }}
            >
              <h1>
                {" "}
                <ContactMailSharpIcon />
              </h1>
            </Link>
          </IconButton>
          <Typography
            variant="subheading"
            color="inherit"
            className={classes.padding}
          >
            <Link
              to="/contactus"
              className={classes.link}
              style={{ textDecoration: "none" }}
            >
              <h4> Contact </h4>
            </Link>
          </Typography>

          {!userService.isLoggedIn() ? (
            <>
              <IconButton
                style={{ marginBottom: "10px", marginRight: "-2px" }}
                color="primary"
                aria-label="upload picture"
                component="span"
              >
                <Link
                  to="/login"
                  className={classes.link}
                  style={{ textDecoration: "none" }}
                >
                  <h1>
                    {" "}
                    <LockOpenIcon />
                  </h1>
                </Link>
              </IconButton>

              <Typography
                variant="subheading"
                color="inherit"
                className={classes.padding}
              >
                <Link
                  to="/login"
                  color="inherit"
                  style={{ textDecoration: "none" }}
                  className={classes.link}
                >
                  <h4> Login </h4>
                </Link>
              </Typography>

              <IconButton
                style={{ marginBottom: "10px", marginRight: "-2px" }}
                color="primary"
                aria-label="upload picture"
                component="span"
              >
                <Link
                  to="/login"
                  className={classes.link}
                  style={{ textDecoration: "none" }}
                >
                  <h1>
                    {" "}
                    <VpnKeyIcon />
                  </h1>
                </Link>
              </IconButton>

              <Typography
                variant="subheading"
                color="inherit"
                className={classes.padding}
              >
                <Link
                  to="/register"
                  className={classes.link}
                  style={{ textDecoration: "none" }}
                >
                  <h4> Register </h4>
                </Link>
              </Typography>
            </>
          ) : (
            <Button
              variant="contained"
              color="primary"
              onClick={(e) => {
                userService.logout();
                window.location.reload();
              }}
            >
              LogOut {userService.getLoggedInUser().name}
            </Button>
          )}
          {/* <Typography
            variant="subheading"
            color="inherit"
            className={classes.padding}
          >
            <Link
              to="/devlab"
              className={classes.link}
              style={{ textDecoration: "none" }}
            >
              <h4> devlab </h4>
            </Link>
          </Typography> */}
        </Toolbar>
      </AppBar>
    );
  }

  render() {
    return (
      <div>
        {this.state.drawerActivate ? this.createDrawer() : this.destroyDrawer()}
      </div>
    );
  }
}

ResAppBar.propTypes = {
  classes: PropTypes.object.isRequired,
};

export default withStyles(styleSheet)(ResAppBar);
