import { Paper } from "@material-ui/core";
import React from "react";

//import IconButton from "material-ui/IconButton";
//import ActionHome from "material-ui/svg-icons/action/home";

import Image from "../1-02.jpg"; // Import using relative path

const styles = {
  paperContainer: {
    height: 50,
    // position: "absolute",
    color: "White",
    justifycontent: "center",
    backgroundSize: "cover",
    backgroundPosition: "center",
    width: `calc(100vw + 48px)`,
    alignText: "center", // marginTop: "-20px",
    backgroundImage: `url(${Image})`,
  },
};
export default class Banner extends React.Component {
  render() {
    return <Paper style={styles.paperContainer}></Paper>;
  }
}
