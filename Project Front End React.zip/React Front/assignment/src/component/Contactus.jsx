import React from "react";

import { Button } from "@material-ui/core";
import BottomSocial from "./BottomSocial";
import Bottom from "./Bottom";
import { Typography, Link } from "@material-ui/core";

const Contactus = () => {
  return (
    <div style={{ marginTop: "100px" }}>
      <Button
        style={{ marginBottom: "8px", marginLeft: "8px" }}
        variant="contained"
        color="primary"
        onClick={() => {
          window.history.back();
        }}
      >
        Go to Back
      </Button>

      <BottomSocial />
      <Bottom />
    </div>
  );
};

export default Contactus;
