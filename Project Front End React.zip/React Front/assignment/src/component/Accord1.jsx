import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import Accordion from "@material-ui/core/Accordion";
import AccordionSummary from "@material-ui/core/AccordionSummary";
import AccordionDetails from "@material-ui/core/AccordionDetails";
import Typography from "@material-ui/core/Typography";
import ExpandMoreIcon from "@material-ui/icons/ExpandMore";

const useStyles = makeStyles((theme) => ({
  root: {
    width: "100%",
  },
  heading: {
    fontSize: theme.typography.pxToRem(15),
    fontWeight: theme.typography.fontWeightRegular,
  },
}));

export default function SimpleAccordion() {
  const classes = useStyles();

  return (
    <div
      className={classes.root}
      style={{ marginTop: "8px", marginBottom: "8px", marginLeft: "8px" }}
    >
      <h2> Latest Hot Television Set </h2>
      <Accordion>
        <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel1a-content"
          id="panel1a-header"
        >
          <Typography className={classes.heading}>
            {" "}
            TCL 50 Inch 4K UHD Smart LED TV (L50P65US) 8,000 Sales Today
          </Typography>
        </AccordionSummary>
        <AccordionDetails>
          <Typography>
            These are some best tv similar to TCL 50 Inch 4K UHD Smart LED TV
            (L50P65US). I think you’ll like them, too.
          </Typography>
        </AccordionDetails>
      </Accordion>
      <Accordion>
        <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel2a-content"
          id="panel2a-header"
        >
          <Typography className={classes.heading}>
            {" "}
            TCL 50 Inch 4K UHD Smart LED TV (L50P65US) 9,000 Sales Today
          </Typography>
        </AccordionSummary>
        <AccordionDetails>
          <Typography>
            These are some best tv similar to TCL 50 Inch 4K UHD Smart LED TV
            (L50P65US). I think you’ll like them, too.
          </Typography>
        </AccordionDetails>
      </Accordion>
      <Accordion disabled>
        <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel3a-content"
          id="panel3a-header"
        >
          <Typography className={classes.heading}>
            TCL 50 Inch 4K FHD Smart LED TV (50P65) 9,000 Sales - No Set
            Available - Sale out Now
          </Typography>
        </AccordionSummary>
      </Accordion>
    </div>
  );
}
