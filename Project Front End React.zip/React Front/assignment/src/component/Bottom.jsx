import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import { AppBar, Box, IconButton, Link } from "@material-ui/core";
import WhatsAppIcon from "@material-ui/icons/WhatsApp";
import EmailIcon from "@material-ui/icons/Email";
import AlternateEmailIcon from "@material-ui/icons/AlternateEmail";
import CopyrightIcon from "@material-ui/icons/Copyright";
const useStyles = makeStyles((theme) => ({
  marginAutoContainer: {
    //width: 500,
    height: 80,
    display: "flex",
    backgroundColor: "lightgrey",
  },
  marginAutoItem: {
    margin: "auto",
  },
  alignItemsAndJustifyContent: {
    //width: 500,
    height: 80,
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    //backgroundColor: "lightblue",
  },
}));
const Bottom = () => {
  const classes = useStyles();
  return (
    <React.Fragment>
      <Box display="flex" height={80} bgcolor="pink">
        <Box m="auto"> We’re always ready to help.</Box>
      </Box>
      <Box
        display="flex"
        height={80}
        bgcolor="white"
        alignItems="center"
        justifyContent="center"
      >
        <IconButton
          color="text.secondary

          "
          aria-label="open drawer"
          edge="start"
          //onClick={toggleDrawer(true)}
          component="span"
        >
          <WhatsAppIcon />
        </IconButton>
        03-111-577-577 Contact us on Whatsapp
      </Box>
      <div className={classes.marginAutoContainer}>
        <div className={classes.marginAutoItem}>
          <IconButton
            color="secondary"
            aria-label="open drawer"
            edge="start"
            //onClick={toggleDrawer(true)}
            component="span"
          >
            <EmailIcon />
          </IconButton>
          Oyemobile@gmail.com
        </div>
      </div>
      <div className={classes.alignItemsAndJustifyContent}>
        <IconButton
          //color="white"
          aria-label="open drawer"
          edge="start"
          //onClick={toggleDrawer(true)}
          component="span"
        >
          <AlternateEmailIcon />
        </IconButton>
        AlternateEmail : Project@gmail.com
      </div>
      <AppBar
        style={{ backgroundColor: "black", height: "70px" }}
        position="static"
      >
        <div>
          <Box
            display="flex"
            height={80}
            alignItems="center"
            justifyContent="center"
          >
            <IconButton
              color="text.secondary
              "
              aria-label="open drawer"
              edge="start"
              //onClick={toggleDrawer(true)}
              component="span"
            >
              <CopyrightIcon />
            </IconButton>
            2021 Oyemobile
          </Box>
        </div>
      </AppBar>
    </React.Fragment>
  );
};
export default Bottom;
