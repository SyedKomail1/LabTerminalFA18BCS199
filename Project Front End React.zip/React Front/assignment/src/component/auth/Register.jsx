import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import { TextField, Button, Typography, Box } from "@material-ui/core";
import userService from "../services/UserService";

//import userService from "../../services/UserService";
import { toast } from "react-toastify";
const useStyles = makeStyles((theme) => ({
  container: {
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    //height: "300px",
    margin: theme.spacing(1),
  },
  child: {
    width: "60%",
  },
  button: {
    marginTop: "50px",
  },
  button1: {
    marginTop: "15px",
  },
}));

const Register = (props) => {
  const classes = useStyles();
  const [email, setEmail] = React.useState("");
  const [password, setPassword] = React.useState("");
  const [name, setName] = React.useState("");

  return (
    <div>
      <Box component="span" m={10}></Box>

      <Typography
        style={{ marginBottom: "8px", marginLeft: "8px" }}
        className={classes.button}
      >
        <h1> Register </h1>
      </Typography>
      <Button
        style={{ marginBottom: "8px", marginLeft: "8px" }}
        variant="contained"
        color="primary"
        onClick={() => {
          window.history.back();
        }}
      >
        Go to Back
      </Button>

      <div className={classes.container}>
        <div className={classes.child}>
          <Box component="span" m={0.5}>
            <h2>Write your Name</h2>
          </Box>
          <TextField
            id="outlined-basic"
            placeholder="e.g JohnSmith"
            //label="Write your Name"
            variant="outlined"
            height="60%"
            fullWidth
            value={name}
            onChange={(e) => {
              setName(e.target.value);
            }}
          />{" "}
          <br />
          <Box component="span" m={0.5}>
            <h2>Write your Email</h2>
          </Box>
          <TextField
            id="outlined-basic"
            placeholder="e.g JohnSmith@gmail.com"
            //label="Write your Email"
            variant="outlined"
            fullWidth
            type="email"
            value={email}
            onChange={(e) => {
              setEmail(e.target.value);
            }}
          />{" "}
          <br />
          <Box component="span" m={0.5}>
            <h2>Write your Password</h2>
          </Box>
          <TextField
            id="outlined-basic"
            // label="Write your Password"
            placeholder="Password"
            variant="outlined"
            type="password"
            fullWidth
            value={password}
            onChange={(e) => {
              setPassword(e.target.value);
            }}
          />{" "}
          <br />
          <br />
          <Box component="span" m={1}></Box>
          <Button
            className={classes.button1}
            variant="contained"
            color="primary"
            onClick={(e) => {
              userService
                .register(name, email, password)
                .then((data) => {
                  console.log(data);
                  toast.success("Register Successfully", {
                    position: toast.POSITION.TOP_CENTER,
                  });

                  props.history.push("/login");
                })
                .catch((err) => {
                  console.log(err);
                  toast.error(err.response.data, {
                    position: toast.POSITION.TOP_LEFT,
                  });
                });
            }}
          >
            Register
          </Button>
        </div>
      </div>
    </div>
  );
};

export default Register;
