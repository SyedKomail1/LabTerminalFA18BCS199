import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import { TextField, Button, Typography, Box } from "@material-ui/core";
import userService from "../services/UserService";
import LockOpenIcon from "@material-ui/icons/LockOpen";

import { toast } from "react-toastify";

//import userService from "../../services/UserService";

const useStyles = makeStyles((theme) => ({
  container: {
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    height: "300px",
  },
  child: {
    width: "60%",
  },
  button: {
    marginTop: "50px",
  },
  button1: {
    marginTop: "25px",
  },
}));
const Login = (props) => {
  const classes = useStyles();
  const [email, setEmail] = React.useState("");
  const [password, setPassword] = React.useState("");
  const [open, setOpen] = React.useState(false);
  const handleClick = () => {
    setOpen(true);
  };

  const handleClose = (event, reason) => {
    if (reason === "clickaway") {
      return;
    }

    setOpen(false);
  };

  return (
    <div>
      <Box component="span" m={10}></Box>
      <Typography
        style={{ marginTop: "70px", marginBottom: "8px", marginLeft: "8px" }}
        className={classes.button}
      >
        <h1> Login </h1>
      </Typography>
      <Button
        style={{ marginBottom: "8px", marginLeft: "8px" }}
        variant="contained"
        color="primary"
        onClick={() => {
          window.history.back();
        }}
      >
        Go to Back
      </Button>

      <div className={classes.container}>
        <div className={classes.child}>
          <h2> Email</h2>
          <TextField
            id="outlined-basic"
            label="Write your Email"
            variant="outlined"
            type="email"
            fullWidth
            value={email}
            onChange={(e) => {
              setEmail(e.target.value);
            }}
          />
          <Box component="span" m={1}></Box>
          <br />
          <h2> Password </h2>
          <TextField
            id="outlined-basic"
            placeholder="Password"
            label="Write your Password"
            variant="outlined"
            type="password"
            fullWidth
            value={password}
            onChange={(e) => {
              setPassword(e.target.value);
            }}
          />{" "}
          <br />
          <Button
            className={classes.button1}
            variant="contained"
            color="primary"
            fullWidth
            onClick={(e) => {
              userService
                .login(email, password)
                .then((data) => {
                  console.log(data);
                  toast.success("Login successfully", {
                    position: toast.POSITION.TOP_CENTER,
                  });
                  window.location.href = "/";
                })
                .catch((err) => {
                  console.log(err);
                  toast.error(err.response.data, {
                    position: toast.POSITION.TOP_LEFT,
                  });
                });
            }}
          >
            Login
          </Button>
        </div>
      </div>
    </div>
  );
};

export default Login;
