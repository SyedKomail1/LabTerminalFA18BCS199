import React from "react";
import SingleProduct from "./SingleProduct";
import Pagination from "@material-ui/lab/Pagination";
import { useHistory } from "react-router-dom";
import { Alert, AlertTitle } from "@material-ui/lab";
import Bottom from "./Bottom";

import {
  Grid,
  Box,
  CardContent,
  Button,
  Card,
  Typography,
} from "@material-ui/core";
//import Fab from "@material-ui/core/Fab";
//import AddIcon from "@material-ui/icons/Add";
import { useCookies } from "react-cookie";

//import { makeStyles } from "@material-ui/core/styles";
import productService from "./services/ProductsService";
import userService from "./services/UserService";

import {
  createMuiTheme,
  withStyles,
  makeStyles,
  ThemeProvider,
} from "@material-ui/core/styles";
//import Button from "@material-ui/core/Button";
import { green, purple } from "@material-ui/core/colors";

const BootstrapButton = withStyles({
  root: {
    boxShadow: "none",
    textTransform: "none",
    fontSize: 16,
    padding: "6px 12px",
    border: "1px solid",
    lineHeight: 1.5,
    //color: theme.palette.getContrastText(purple[500]),
    backgroundColor: purple[500],
    //backgroundColor: "#0063cc",
    borderColor: "#0063cc",
    fontFamily: [
      "-apple-system",
      "BlinkMacSystemFont",
      '"Segoe UI"',
      "Roboto",
      '"Helvetica Neue"',
      "Arial",
      "sans-serif",
      '"Apple Color Emoji"',
      '"Segoe UI Emoji"',
      '"Segoe UI Symbol"',
    ].join(","),
    "&:hover": {
      backgroundColor: "#0069d9",
      borderColor: "#0062cc",
      boxShadow: "none",
    },
    "&:active": {
      boxShadow: "none",
      backgroundColor: "#0062cc",
      borderColor: "#005cbf",
    },
    "&:focus": {
      boxShadow: "0 0 0 0.2rem rgba(0,123,255,.5)",
    },
  },
})(Button);

const ColorButton = withStyles((theme) => ({
  root: {
    color: theme.palette.getContrastText(purple[500]),
    backgroundColor: purple[500],
    "&:hover": {
      backgroundColor: purple[700],
    },
  },
}))(Button);

const useStyles = makeStyles((theme) => ({
  margin: {
    margin: theme.spacing(1),
  },
  rootpage: {
    marginTop: "20",
  },
}));

const theme = createMuiTheme({
  palette: {
    primary: green,
  },
});

const Products = (props) => {
  const [products, setProducts] = React.useState([]);
  const classes = useStyles();
  const page = props.match.params.page ? props.match.params.page : 1;
  const [total, setTotal] = React.useState(0);
  const { push } = useHistory();
  const [perPage, setPerPage] = React.useState(10);
  const [cookies, setCookie, removeCookie] = useCookies(["cart"]);

  const getData = () => {
    productService
      .getProducts(page, perPage)
      .then((data) => {
        setProducts(data.products);
        setTotal(data.total);
      })
      .catch((err) => {
        console.log(err);
      });
  };
  // getData();
  React.useEffect(getData, [page, perPage]); // after click [page], refresh page, for pagination
  // console.log("Inside Products Component");

  const handleNewProductClick = () => {
    console.log(props);
    props.history.push("/products/new");
  };
  return (
    <div
      style={{ marginTop: "110px", marginLeft: "30px", marginRight: "30px" }}
    >
      <div style={{ marginLeft: "30px" }}>
        <ThemeProvider theme={theme}>
          <Button
            style={{ marginRight: "30px" }}
            variant="contained"
            color="primary"
            onClick={() => {
              window.history.back();
            }}
          >
            {" "}
            Go to Back
          </Button>
        </ThemeProvider>
        <ThemeProvider theme={theme}>
          <Button
            variant="contained"
            color="primary"
            onClick={() => push("/cart")}
          >
            View all Cart Items
          </Button>
        </ThemeProvider>
      </div>

      <Card
        style={{
          marginTop: "15px",
          marginLeft: "30px",
          marginRight: "30px",
          marginBottom: "15px",
        }}
        className={classes.root}
        variant="outlined"
      >
        <CardContent>
          <Typography variant="h5" component="h2">
            Select number of pages
          </Typography>
          <ThemeProvider theme={theme}>
            <select
              value={perPage}
              onChange={(e) => setPerPage(e.target.value)}
              style={{ width: "100px", height: "30px" }}
            >
              <option value="2">Two</option>
              <option value="3">Three</option>
              <option value="4">Four</option>
              <option value="5">Five</option>
              <option value="6">Six</option>
              <option value="7">Seven</option>
              <option value="8">Eight</option>
              <option value="9">Nine</option>
              <option value="10">Ten</option>
            </select>
          </ThemeProvider>
        </CardContent>
      </Card>
      <Box component="span" m={2}></Box>
      {userService.isAdmin() && (
        <ColorButton
          variant="contained"
          color="primary"
          className={classes.margin}
          onClick={handleNewProductClick}
        >
          Add Product
        </ColorButton>
      )}
      <Box component="span" m={1}></Box>

      <Typography variant="body2" component="p">
        <h1>Products</h1>
      </Typography>

      {products.length == 0 ? (
        <div>
          <Alert severity="info">
            <AlertTitle> Hey There </AlertTitle>
            Sorry we don,t have Products available! Better Luck next Time —{" "}
            <strong> check it out! Tomorrow </strong>
          </Alert>
        </div>
      ) : (
        <Grid container spacing={3}>
          {products.map((product, index) => (
            <SingleProduct key={index} product={product} onDelete={getData} />
          ))}
        </Grid>
      )}
      <Grid item xs={12}>
        <Box component="span" m={0.5}>
          {" "}
        </Box>
        <Pagination
          count={Math.ceil(total / 2)}
          // margin="5"
          color="secondary"
          variant="outlined"
          shape="rounded"
          onChange={(e, value) => {
            console.log(value);
            props.history.push("/products/" + value);
          }}
        />
        Total: {total} Showing {(page - 1) * perPage} to{" "}
        {(page - 1) * perPage + products.length}
      </Grid>
      <Bottom />
    </div>
  );
};

export default Products;
