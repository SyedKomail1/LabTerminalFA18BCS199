import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import Card from "@material-ui/core/Card";
import CardActionArea from "@material-ui/core/CardActionArea";
import CardActions from "@material-ui/core/CardActions";
import CardContent from "@material-ui/core/CardContent";
import CardMedia from "@material-ui/core/CardMedia";
import Button from "@material-ui/core/Button";
import Typography from "@material-ui/core/Typography";
//import { AppBar, Box, IconButton, Link } from "@material-ui/core";
import logo from "../p1.jpg";
import logo1 from "../p2.jpg";
import logo2 from "../p3.jpg";
import logo3 from "../p4.jpg";
import { Grid } from "@material-ui/core";
import { useHistory } from "react-router-dom";
import Hidden from "@material-ui/core/Hidden";

import Snackbar from "@material-ui/core/Snackbar";
import MuiAlert from "@material-ui/lab/Alert";

const useStyles = makeStyles((theme) => ({
  root: {
    flexGrow: 1,
    margin: 25,
  },

  Media: {
    width: "150px",
    height: "150px",
    display: "flex",
    justifyContent: "center",
  },
  card: {
    // padding: theme.spacing(2),
    textAlign: "center",
  },
}));
function Alert(props) {
  return <MuiAlert elevation={6} variant="filled" {...props} />;
}

export default function Mediacard(props) {
  const classes = useStyles();
  const { push } = useHistory();
  const { width } = props;

  const [open, setOpen] = React.useState(false);

  const handleClick = () => {
    setOpen(true);
  };

  const handleClose = (event, reason) => {
    if (reason === "clickaway") {
      return;
    }

    setOpen(false);
  };

  return (
    <div className={classes.root}>
      <h3> Best Seller</h3>
      <Grid
        container
        //spacing={0}
        direction="row"
        alignItems="center"
        justify="center"
        // style={{ minHeight: "50vh" }}
        container
        //spacing={1}
      >
        <Hidden xsDown>
          <Grid item xs={2} sm={3} md={3} lg={3} xl={3}>
            <Card className={classes.root}>
              <CardActionArea>
                <div style={{ display: "flex", justifyContent: "center" }}>
                  <CardMedia
                    className={classes.Media}
                    component="img"
                    justifyContent="center"
                    alt="Contemplative Reptile"
                    //height="70"
                    img
                    src={logo}
                    title="Contemplative Reptile"
                  />
                </div>
                <CardContent className={classes.card}>
                  <Typography gutterBottom variant="h5" component="h2">
                    Xiaomi Redmi Note 10
                  </Typography>
                  <Typography
                    variant="body2"
                    color="textSecondary"
                    component="p"
                  >
                    Rs. 1,900 OFF
                  </Typography>

                  <Button
                    type="button"
                    color="primary"
                    variant="contained"
                    onClick={() => push("/products")}
                  >
                    Shop Now
                  </Button>
                </CardContent>
              </CardActionArea>
            </Card>
          </Grid>
        </Hidden>
        <Hidden smDown>
          <Grid item xs={2} sm={3} md={3} lg={3} xl={3}>
            <Card className={classes.root}>
              <CardActionArea>
                <div style={{ display: "flex", justifyContent: "center" }}>
                  <CardMedia
                    className={classes.Media}
                    component="img"
                    justifyContent="center"
                    alt="Contemplative Reptile"
                    //height="70"
                    img
                    src={logo1}
                    title="Contemplative Reptile"
                  />
                </div>
                <CardContent className={classes.card}>
                  <Typography gutterBottom variant="h5" component="h2">
                    Xiaomi Redmi Note 10
                  </Typography>
                  <Typography
                    variant="body2"
                    color="textSecondary"
                    component="p"
                  >
                    Rs. 1,900 OFF
                  </Typography>
                  <Button
                    type="button"
                    color="primary"
                    variant="contained"
                    onClick={() => push("/products")}
                  >
                    Shop Now
                  </Button>
                </CardContent>
              </CardActionArea>
            </Card>
          </Grid>
        </Hidden>
        <Hidden mdDown>
          <Grid item xs={2} sm={3} md={3} lg={3} xl={3}>
            <Card className={classes.root}>
              <CardActionArea>
                <div style={{ display: "flex", justifyContent: "center" }}>
                  <CardMedia
                    className={classes.Media}
                    component="img"
                    justifyContent="center"
                    alt="Contemplative Reptile"
                    //height="70"
                    img
                    src={logo2}
                    title="Contemplative Reptile"
                  />
                </div>
                <CardContent className={classes.card}>
                  <Typography gutterBottom variant="h5" component="h2">
                    Xiaomi Redmi Note 10
                  </Typography>
                  <Typography
                    variant="body2"
                    color="textSecondary"
                    component="p"
                  >
                    Rs. 1,900 OFF
                  </Typography>
                  <Button
                    type="button"
                    color="primary"
                    variant="contained"
                    onClick={() => push("/products")}
                  >
                    Shop Now
                  </Button>
                </CardContent>
              </CardActionArea>
            </Card>
          </Grid>
        </Hidden>
        <Hidden lgDown>
          <Grid item xs={2} sm={3} md={3} lg={3} xl={3}>
            <Card className={classes.root}>
              <CardActionArea>
                <div style={{ display: "flex", justifyContent: "center" }}>
                  <CardMedia
                    className={classes.Media}
                    component="img"
                    justifyContent="center"
                    alt="Contemplative Reptile"
                    //height="70"
                    img
                    src={logo3}
                    title="Contemplative Reptile"
                  />
                </div>
                <CardContent className={classes.card}>
                  <Typography gutterBottom variant="h5" component="h2">
                    Xiaomi Redmi Note 10
                  </Typography>
                  <Typography
                    variant="body2"
                    color="textSecondary"
                    component="p"
                  >
                    Rs. 1,900 OFF
                  </Typography>
                  <Button
                    type="button"
                    color="primary"
                    variant="contained"
                    onClick={() => push("/products")}
                  >
                    Shop Now
                  </Button>
                </CardContent>
              </CardActionArea>
            </Card>
          </Grid>
        </Hidden>

        <Button
          //href="/"
          type="button"
          color="primary"
          variant="contained"
          onClick={function (event) {
            handleClick();

            setTimeout(() => {
              push("/products");
            }, 1000);
          }}
        >
          View All Latest HD Mobiles
        </Button>

        <Snackbar open={open} autoHideDuration={6000} onClose={handleClose}>
          <Alert onClose={handleClose} severity="success">
            Directing you to the Product Page
          </Alert>
        </Snackbar>
      </Grid>
    </div>
  );
}
