import { ImportantDevices } from "@material-ui/icons";
import React from "react";
import Carousel from "react-elastic-carousel";
import { AppBar, Box, IconButton, Link } from "@material-ui/core";
//import Card from "./Card";
import Image from "../cor4.png";
import Image1 from "../cor5.png";
import Image2 from "../cor3.png";
import Image3 from "../cor2.png";
import Image4 from "../cor1.png";
import Image5 from "../cor4.png";
const styles = {
  paperContainer: {
    // width: 400,
    //height: "100vh",
    background: "white",
    color: "red",

    // justifycontent: "center",
    // alignitem: "center",
    //backgroundSize: "cover",
    //backgroundPosition: "center",
    //width: "100%",
    //paddingTop: "50px",
    //margin: -400,
    //padding: 300,
    // alignitems: "center",
    //display: "contents",
  },
  cardimg: {
    width: 10,
    height: "auto",
    display: "block",
    objectfit: "cover",
  },
};

const Bannercoursel = () => {
  const Card = ({ cardImage }) => (
    <div className="card">
      <img src={cardImage} alt="cardImage" />
    </div>
  );
  /*
  const breakPoints = [
    { width: 1, itemsToShow: 1 },
    { width: 900, itemsToShow: 2 },
    { width: 1000, itemsToShow: 3 },
    { width: 1200, itemsToShow: 4 },
  ];
  //breakPoints={breakPoints}
  */

  return (
    <div style={styles.paperContainer}>
      <Carousel>
        <Card style={styles.cardimg} cardImage={Image} />
        <Card style={styles.cardimg} cardImage={Image1} />
        <Card style={styles.cardimg} cardImage={Image2} />
        <Card style={styles.cardimg} cardImage={Image3} />
        <Card style={styles.cardimg} cardImage={Image4} />
        <Card style={styles.cardimg} cardImage={Image5} />
      </Carousel>
      <Box component="span" m={1}></Box>;
    </div>
  );
};

export default Bannercoursel;
