import React from "react";
import { ToastContainer } from "react-toastify";
import Bannercoursel from "./Bannercoursel";
import Bottom from "./Bottom";
import Mediacard from "./Mediacard";
import TabNew from "./TabNew";
import Mediacard2 from "./Mediacard2";
import Respondcard1 from "./RespondCard1";
import Respondcard2 from "./RespondCard2";
import Respondcard from "./RespondCard";
import Banner from "./Banner";
import Banner1 from "./Banner1";
import Banner2 from "./Banner2";
import Banner3 from "./Banner3";
import Banner7 from "./Banner7";
import Accord from "./Accord";
import Accord1 from "./Accord1";

import BottomSocial from "./BottomSocial";

import { Button, Box, IconButton, Link } from "@material-ui/core";
import {
  createMuiTheme,
  ThemeProvider,
  withStyles,
  makeStyles,
} from "@material-ui/core/styles";
import { green, purple } from "@material-ui/core/colors";

const BootstrapButton = withStyles({
  root: {
    boxShadow: "none",
    textTransform: "none",
    fontSize: 16,
    padding: "6px 12px",
    border: "1px solid",
    lineHeight: 1.5,
    //color: theme.palette.getContrastText(purple[500]),
    backgroundColor: purple[500],
    //backgroundColor: "#0063cc",
    borderColor: "#0063cc",
    fontFamily: [
      "-apple-system",
      "BlinkMacSystemFont",
      '"Segoe UI"',
      "Roboto",
      '"Helvetica Neue"',
      "Arial",
      "sans-serif",
      '"Apple Color Emoji"',
      '"Segoe UI Emoji"',
      '"Segoe UI Symbol"',
    ].join(","),
    "&:hover": {
      backgroundColor: "#0069d9",
      borderColor: "#0062cc",
      boxShadow: "none",
    },
    "&:active": {
      boxShadow: "none",
      backgroundColor: "#0062cc",
      borderColor: "#005cbf",
    },
    "&:focus": {
      boxShadow: "0 0 0 0.2rem rgba(0,123,255,.5)",
    },
  },
})(Button);

const ColorButton = withStyles((theme) => ({
  root: {
    color: theme.palette.getContrastText(purple[500]),
    backgroundColor: purple[500],
    "&:hover": {
      backgroundColor: purple[700],
    },
  },
}))(Button);

const useStyles = makeStyles((theme) => ({
  margin: {
    margin: theme.spacing(1),
  },
  rootpage: {
    marginTop: "20",
  },
}));

const theme = createMuiTheme({
  palette: {
    primary: green,
  },
});

const LandingPage = () => {
  const classes = useStyles();

  return (
    <div style={{ marginTop: "1px" }}>
      <ToastContainer />
      <ThemeProvider theme={theme}>
        <Box component="span" m={10}></Box>
        <Banner7 />
        <Box component="span" m={10}></Box>
        <TabNew />
        <Banner />
        <Box component="span" m={1}></Box>;
        <Bannercoursel />
        <Banner1 />
        <Box component="span" m={1}></Box>
        <Respondcard1 />
        <Box component="span" m={1}></Box>
        <Banner3 />
        <Box component="span" m={1}></Box>
        <Banner1 />
        <Box component="span" m={1}></Box>
        <Accord1 />
        <Box component="span" m={1}></Box>
        <Banner3 />
        <Respondcard />
        <Box component="span" m={1}></Box>
        <Banner1 />
        <Box component="span" m={1}></Box>
        <Accord />
        <Box component="span" m={1}></Box>
        <Banner1 />
        <Respondcard2 />
        <Box component="span" m={1}></Box>
        <Banner3 />
        <Box component="span" m={5}></Box>
        <BottomSocial />
        <Bottom />
      </ThemeProvider>
    </div>
  );
};

export default LandingPage;
