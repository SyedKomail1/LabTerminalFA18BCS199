import React from "react";
import { useCookies } from "react-cookie";
import { Button } from "@material-ui/core";
import Card from "@material-ui/core/Card";
import CardActions from "@material-ui/core/CardActions";
import CardContent from "@material-ui/core/CardContent";
import Typography from "@material-ui/core/Typography";
import { makeStyles } from "@material-ui/core/styles";
import userService from "./services/UserService";

const useStyles = makeStyles({
  root: {
    minWidth: 275,
  },
  bullet: {
    display: "inline-block",
    margin: "0 2px",
    transform: "scale(0.8)",
  },
  title: {
    fontSize: 14,
  },
  pos: {
    marginBottom: 12,
  },
});

const Cart = () => {
  const [cookies, setCookie, removeCookie] = useCookies(["cart"]);
  const [myCartProducts, setMyCartProducts] = React.useState([[]]);
  const classes = useStyles();
  const handleRemoveCookie = () => {
    const { cookies } = this.props;
    cookies.remove("user"); // remove the cookie
    this.setState({ user: cookies.get("user") });
  };

  const total = myCartProducts.reduce(function (accumulator, currentValue) {
    return accumulator + currentValue.price;
  }, 0);
  React.useEffect(() => {
    if (cookies.cart) {
      setMyCartProducts(cookies.cart);
    }
  }, [cookies]);
  return (
    <div style={{ marginTop: "120px" }}>
      <div className="container">
        <Button
          style={{ marginBottom: "8px", marginLeft: "8px" }}
          variant="contained"
          color="primary"
          onClick={() => {
            window.history.back();
          }}
        >
          Go to Back
        </Button>

        <Card className={classes.root} variant="outlined">
          <CardContent>
            <Typography
              className={classes.title}
              color="textSecondary"
              gutterBottom
            >
              <table className="table">
                <thead>
                  <tr>
                    <th>Product Name</th>

                    <th>Price</th>

                    <th>Description</th>
                  </tr>
                </thead>
                <tbody>
                  {myCartProducts.map((product, index) => (
                    <tr key={index}>
                      <td>{product.name}</td>
                      <td> Rs {product.price}</td>
                      <td> Rs {product.description}</td>
                      {userService.isAdmin() && (
                        <>
                          <Button
                            variant="contained"
                            color="primary"
                            onClick={(e) => {
                              removeCookie(cookies);
                            }}
                          >
                            Edit
                          </Button>{" "}
                          <Button
                            variant="contained"
                            color="secondary"
                            onClick={(e) => {
                              removeCookie(cookies);
                            }}
                          >
                            Delete
                          </Button>
                        </>
                      )}
                    </tr>
                  ))}
                </tbody>
                <tfoot>
                  <tr>
                    <td>Grand Total</td>
                    <td> Rs. {total}</td>
                  </tr>
                </tfoot>
              </table>
            </Typography>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Cart;
