import { ImportantDevices } from "@material-ui/icons";
import React from "react";

const Cart = () => {
  return <h1> hello1 </h1>;
};

export default Cart;
