import { Paper, Typography } from "@material-ui/core";
import React from "react";

//import IconButton from "material-ui/IconButton";
//import ActionHome from "material-ui/svg-icons/action/home";

import Image from "../29.jpg"; // Import using relative path

const styles = {
  paperContainer: {
    height: 1000,
    // position: "absolute",
    color: "White",
    justifycontent: "center",
    backgroundSize: "cover",
    backgroundPosition: "center",
    width: `calc(100vw + 48px)`,
    alignText: "center", // marginTop: "-20px",
    backgroundImage: `url(${Image})`,
  },
  container: {
    position: "absolute",
    top: 0,
    left: 0,
    width: "100%",
    height: "100%",
  },
};
export default class Banner extends React.Component {
  render() {
    return (
      <div>
        <Paper
          style={{
            height: 100,
            width: 100,
            position: "relative", // because it's parent
            top: 2,
            left: 1,
          }}
          style={styles.paperContainer}
        ></Paper>
        <div style={{}}>
          <Typography
            style={{
              fontWeight: "bold",
              fontFamily: "Roboto",
              //backgroundColor: "rgba(52, 52, 52, 0.2)",
              color: "red",
              textShadowOffset: { width: 8, height: 2 },
              textShadowRadius: 10,
              textShadowColor: "blue",

              fontSize: "60px",
              //color: "white",
              position: "absolute", // child
              bottom: 400, // position where you want
              left: 150,
            }}
          >
            <h1>OYE MOBILE</h1>
            <h2
              style={{
                color: "white",
              }}
            >
              Lowest Mobile Price In Pakistan
            </h2>
          </Typography>
        </div>
      </div>
    );
  }
}
