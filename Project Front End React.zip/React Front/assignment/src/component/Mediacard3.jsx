import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import Card from "@material-ui/core/Card";
import CardActionArea from "@material-ui/core/CardActionArea";
//import CardActions from "@material-ui/core/CardActions";
import CardContent from "@material-ui/core/CardContent";
import CardMedia from "@material-ui/core/CardMedia";
import Button from "@material-ui/core/Button";
import Typography from "@material-ui/core/Typography";
//import { AppBar, Box, IconButton, Link } from "@material-ui/core";
import logo from "../b1 (1).jpg";
import logo1 from "../b1 (2).jpg";
import logo2 from "../b1 (3).jpg";
import logo3 from "../b1 (4).jpg";
import { Grid } from "@material-ui/core";
import { Link } from "react-router-dom";
import { useHistory } from "react-router-dom";
import Hidden from "@material-ui/core/Hidden";

const useStyles = makeStyles((theme) => ({
  root: {
    flexGrow: 1,
    margin: 25,
  },

  Media: {
    width: "150px",
    height: "150px",
    display: "flex",
    justifyContent: "center",
  },
  card: {
    // padding: theme.spacing(2),
    textAlign: "center",
  },
}));

export default function Mediacard3() {
  const classes = useStyles();
  const { push } = useHistory();

  return (
    <div className={classes.root}>
      <h3> Freezers </h3>
      <Grid
        container
        //spacing={0}
        direction="row"
        alignItems="center"
        justify="center"
        // style={{ minHeight: "50vh" }}
        container
        //spacing={1}
      >
        <Hidden xsDown>
          <Grid item xs={1} sm={3} md={3} lg={3} xl={3}>
            <Card className={classes.root}>
              <CardActionArea>
                <div style={{ display: "flex", justifyContent: "center" }}>
                  <CardMedia
                    className={classes.Media}
                    component="img"
                    justifyContent="center"
                    alt="Contemplative Reptile"
                    //height="70"
                    img
                    src={logo}
                    title="Contemplative Reptile"
                  />
                </div>
                <CardContent className={classes.card}>
                  <Typography gutterBottom variant="h5" component="h2">
                    Samsung 23 cu ft
                  </Typography>
                  <Typography
                    variant="body2"
                    color="textSecondary"
                    component="p"
                  >
                    Rs. 77,900 OFF
                  </Typography>
                  <Button
                    variant="contained"
                    color="primary"
                    component={Link}
                    onClick={() => push("/products")}
                    //justify="right"
                  >
                    Shop Now
                  </Button>
                </CardContent>
              </CardActionArea>
            </Card>
          </Grid>
        </Hidden>
        <Hidden smDown>
          <Grid item xs={1} sm={3} md={3} lg={3} xl={3}>
            <Card className={classes.root}>
              <CardActionArea>
                <div style={{ display: "flex", justifyContent: "center" }}>
                  <CardMedia
                    className={classes.Media}
                    component="img"
                    justifyContent="center"
                    alt="Contemplative Reptile"
                    //height="70"
                    img
                    src={logo1}
                    title="Contemplative Reptile"
                  />
                </div>
                <CardContent className={classes.card}>
                  <Typography gutterBottom variant="h5" component="h2">
                    Samsung 14 cu ft
                  </Typography>
                  <Typography
                    variant="body2"
                    color="textSecondary"
                    component="p"
                  >
                    Rs. 45,900 OFF
                  </Typography>
                  <Button
                    variant="contained"
                    color="primary"
                    component={Link}
                    onClick={() => push("/products")}
                    //justify="right"
                  >
                    Shop Now
                  </Button>
                </CardContent>
              </CardActionArea>
            </Card>
          </Grid>
        </Hidden>
        <Hidden mdDown>
          <Grid xs={1} sm={3} md={3} lg={3} xl={3}>
            <Card className={classes.root}>
              <CardActionArea>
                <div style={{ display: "flex", justifyContent: "center" }}>
                  <CardMedia
                    className={classes.Media}
                    component="img"
                    justifyContent="center"
                    alt="Contemplative Reptile"
                    //height="70"
                    img
                    src={logo2}
                    title="Contemplative Reptile"
                  />
                </div>
                <CardContent className={classes.card}>
                  <Typography gutterBottom variant="h5" component="h2">
                    Haier 17 cu ft Double
                  </Typography>
                  <Typography
                    variant="body2"
                    color="textSecondary"
                    component="p"
                  >
                    Rs. 56,900 OFF
                  </Typography>
                  <Button
                    variant="contained"
                    color="primary"
                    component={Link}
                    onClick={() => push("/products")}
                    //justify="right"
                  >
                    Shop Now
                  </Button>
                </CardContent>
              </CardActionArea>
            </Card>
          </Grid>
        </Hidden>
        <Hidden lgDown>
          <Grid xs={1} sm={3} md={3} lg={3} xl={3}>
            <Card className={classes.root}>
              <CardActionArea>
                <div style={{ display: "flex", justifyContent: "center" }}>
                  <CardMedia
                    className={classes.Media}
                    component="img"
                    justifyContent="center"
                    alt="Contemplative Reptile"
                    //height="70"
                    img
                    src={logo3}
                    title="Contemplative Reptile"
                  />
                </div>
                <CardContent className={classes.card}>
                  <Typography gutterBottom variant="h5" component="h2">
                    Haier 17 cu ft Double
                  </Typography>
                  <Typography
                    variant="body2"
                    color="textSecondary"
                    component="p"
                  >
                    Rs. 75,000 OFF
                  </Typography>
                  <Button
                    variant="contained"
                    color="primary"
                    component={Link}
                    onClick={() => push("/products")}
                    //justify="right"
                  >
                    Shop Now
                  </Button>
                </CardContent>
              </CardActionArea>
            </Card>
          </Grid>
        </Hidden>
        <Button
          variant="contained"
          color="primary"
          component={Link}
          onClick={() => push("/products")}
          //justify="right"
        >
          View All Latest Freezers
        </Button>
      </Grid>
    </div>
  );
}
