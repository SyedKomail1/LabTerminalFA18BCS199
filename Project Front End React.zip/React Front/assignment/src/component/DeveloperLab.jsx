import React from "react";

import { Button } from "@material-ui/core";
import BottomSocial from "./BottomSocial";
import Bottom from "./Bottom";
import { Grid, Box, IconButton, Link } from "@material-ui/core";
import Snackbar from "@material-ui/core/Snackbar";
import MuiAlert from "@material-ui/lab/Alert";
import { makeStyles } from "@material-ui/core/styles";
import { useHistory } from "react-router-dom";

const useStyles = makeStyles((theme) => ({
  root: {
    width: "100%",
    "& > * + *": {
      marginTop: theme.spacing(2),
    },
  },
}));
const DeveloperLab = () => {
  const classes = useStyles();
  const { push } = useHistory();

  function Alert(props) {
    return <MuiAlert elevation={6} variant="filled" {...props} />;
  }
  const [open, setOpen] = React.useState(false);

  const handleClick = () => {
    setOpen(true);
  };

  const handleClose = (event, reason) => {
    if (reason === "clickaway") {
      return;
    }

    setOpen(false);
  };

  return (
    <div style={{ marginTop: "80px" }}>
      <Button
        style={{ marginBottom: "8px", marginLeft: "8px" }}
        variant="contained"
        color="primary"
        onClick={() => {
          window.history.back();
        }}
      >
        Go to Back
      </Button>

      <Button
        //href="/"
        onClick={function (event) {
          handleClick();

          setTimeout(() => {
            push("/products");
          }, 1000);
        }}
      >
        Test Link
      </Button>
      <div className={classes.root}>
        <Button variant="outlined" onClick={handleClick}>
          Open success snackbar
        </Button>
        <Snackbar open={open} autoHideDuration={6000} onClose={handleClose}>
          <Alert onClose={handleClose} severity="success">
            This is a success message!
          </Alert>
        </Snackbar>

        <Alert severity="error">This is an error message!</Alert>
        <Alert severity="warning">This is a warning message!</Alert>
        <Alert severity="info">This is an information message!</Alert>
        <Alert severity="success">This is a success message!</Alert>

        <Bottom />
      </div>
    </div>
  );
};

export default DeveloperLab;
