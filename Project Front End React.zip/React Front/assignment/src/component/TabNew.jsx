import React from "react";

import PropTypes from "prop-types";
import { makeStyles } from "@material-ui/core/styles";
import AppBar from "@material-ui/core/AppBar";
import Tabs from "@material-ui/core/Tabs";
import Tab from "@material-ui/core/Tab";
import Typography from "@material-ui/core/Typography";
import Box from "@material-ui/core/Box";
import { Button, Link } from "@material-ui/core";

function TabPanel(props) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      aria-labelledby={`simple-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box p={1}>
          <Typography>{children}</Typography>
        </Box>
      )}
    </div>
  );
}

TabPanel.propTypes = {
  children: PropTypes.node,
  index: PropTypes.any.isRequired,
  value: PropTypes.any.isRequired,
};

function a11yProps(index) {
  return {
    id: `simple-tab-${index}`,
    "aria-controls": `simple-tabpanel-${index}`,
  };
}

const useStyles = makeStyles(() => ({
  root: {
    backgroundSize: "cover",
    backgroundPosition: "center",
    width: `calc(100vw + 48px)`,
    alignText: "center",
    marginTop: "20px", // marginTop: "-20px",
    //flexGrow: 1,
    //backgroundColor: "lightgrey",
  },
}));

export default function SimpleTabs() {
  const classes = useStyles();
  const [value, setValue] = React.useState(0);

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  return (
    <div
      style={{
        marginTop: "25px",
      }}
      className={classes.root}
    >
      <h1> Latest Trending Mobiles with best prices </h1>
      <AppBar position="static">
        <Tabs
          backgroundColor="#2e1534"
          value={value}
          onChange={handleChange}
          aria-label="simple tabs example"
        >
          <Tab
            label="Xiaomi Redmi Note 10
"
            {...a11yProps(0)}
          />

          <Tab label="Xiaomi Poco X3 Pro" {...a11yProps(1)} />
          <Tab label="Oppo F19 Pro" {...a11yProps(2)} />
          <Tab label="Samsung Galaxy A12" {...a11yProps(2)} />
          <Tab label="Xiaomi Redmi Note 10S" {...a11yProps(2)} />
        </Tabs>
      </AppBar>
      <TabPanel value={value} index={0}>
        10 Sets Remaining
      </TabPanel>
      <TabPanel value={value} index={1}>
        30 Sets Remaining
      </TabPanel>
      <TabPanel value={value} index={2}>
        20 Sets Remaining
      </TabPanel>
      <TabPanel value={value} index={3}>
        20 Sets Remaining
      </TabPanel>
      <TabPanel value={value} index={4}>
        2 Remaining
      </TabPanel>
    </div>
  );
}
