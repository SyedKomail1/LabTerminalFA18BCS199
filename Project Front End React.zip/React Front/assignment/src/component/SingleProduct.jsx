import { Grid, CardContent, Button, Card } from "@material-ui/core";
import React from "react";
import productService from "./services/ProductsService";
import { withRouter } from "react-router";
import userService from "./services/UserService";
import { makeStyles } from "@material-ui/core/styles";
import logo from "../product.jpg";
import { toast } from "react-toastify";

import { useCookies } from "react-cookie";

const useStyles = makeStyles({
  root: {
    //minWidth: 150,
    //minHeight: 200,
    textAlignLast: "center",
  },
  bullet: {
    display: "inline-block",
    margin: "0 1px",
    transform: "scale(2)",
  },
  title: {
    fontSize: 14,
  },
  pos: {
    marginBottom: 12,
  },
  root1: {
    minWidth: 20,
    minHeight: 20,
  },
});

const SingleProduct = (props) => {
  const [cookies, setCookie, removeCookie] = useCookies(["cart"]);

  const { product, onDelete, history } = props;
  console.log(props);
  const classes = useStyles();
  React.useEffect(() => {
    if (!cookies.cart) {
      setCookie("cart", JSON.stringify([]));
    }
  }, []);
  const addProductToCart = (product) => {
    let newCart = [...cookies.cart];
    newCart.push(product);
    setCookie("cart", JSON.stringify(newCart));
    console.log(newCart);
    toast.success(product.name + " added to Cart");
  };

  //const {10, addItem } = useCart();

  return (
    <Grid item xs={1} sm={3}>
      <Card className={classes.root} variant="outlined">
        <CardContent>
          <h1>{product.name}</h1>
        </CardContent>
        <div>
          <img src={logo} height={150} width={150} alt="logo" />
        </div>
        <CardContent>
          {" "}
          <h2> Rs. {product.price}</h2>
        </CardContent>
        <CardContent> {product.description}</CardContent>
      </Card>
      <h2>
        {userService.isAdmin() && (
          <>
            <Button
              variant="contained"
              color="primary"
              onClick={(e) => {
                console.log("navigate to update");
                history.push("/products/update/" + product._id);
              }}
            >
              Edit
            </Button>{" "}
            <Button
              variant="contained"
              color="secondary"
              onClick={(e) => {
                productService
                  .deleteProduct(product._id)
                  .then((data) => {
                    console.log(data);
                    onDelete();
                  })
                  .catch((err) => {
                    console.log(err);
                  });
              }}
            >
              Delete
            </Button>
          </>
        )}
        {"    "}

        <Button
          variant="contained"
          color="primary"
          onClick={() => {
            window.history.back();
          }}
        >
          Go to Back
        </Button>
        {"    "}
        <Button
          variant="contained"
          color="primary"
          disableRipple
          className={classes.margin}
          onClick={(e) => {
            addProductToCart(product);
          }}
        >
          Add to Cart
        </Button>
      </h2>
    </Grid>
  );
};

export default withRouter(SingleProduct);
