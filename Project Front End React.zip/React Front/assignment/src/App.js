import React from "react";
//import TopMenu from "./component/TopMenu";
import {
  BrowserRouter as Router,
  Switch,
  Route,
  Redirect,
} from "react-router-dom";
import LandingPage from "./component/LandingPage";
import Products from "./component/products";
import Contactus from "./component/Contactus";
import Notfound from "./component/Notfound";
import DeveloperLab from "./component/DeveloperLab";

//import Login from "./component/Login";
import NewProduct from "./component/NewProduct";
import UpdateProduct from "./component/UpdateProduct";
import Register from "./component/auth/Register";
import Login from "./component/auth/Login";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import ResAppBar from "./component/ResAppBar";
import Cart from "./component/Cart";
import { CookiesProvider } from "react-cookie";

//import Prod from "./component/productcopy";
import "../node_modules/bootstrap/dist/css/bootstrap.min.css";

//<TopMenu />
function App() {
  return (
    <Router>
      <CookiesProvider>
        <div>
          <ToastContainer />

          <ResAppBar />
          <div style={{ marginTop: "10px" }}>
            <Switch>
              <Route path="/login" component={Login} />
              <Route path="/register" component={Register} />
              <Route path="/contactus" component={Contactus} />
              <Route path="/products/new" component={NewProduct} />
              <Route path="/products/update/:id" component={UpdateProduct} />
              <Route path="/products/:page?" component={Products} />
              <Route path="/devlab" component={DeveloperLab} />
              <Route path="/cart" component={Cart} />

              <Route path="/notfound" component={Notfound} />
              <Route path="/login" component={Login} />

              <Route path="/" exact component={LandingPage} />
              <Redirect to="/notfound" />
            </Switch>
          </div>
        </div>
      </CookiesProvider>
    </Router>
  );
}

export default App;
