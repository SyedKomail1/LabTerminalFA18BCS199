const createProduct = async (title, price, color)=>{
    console.log("create product");
};

const productModel = require()
module.exports,createProduct = createProduct;