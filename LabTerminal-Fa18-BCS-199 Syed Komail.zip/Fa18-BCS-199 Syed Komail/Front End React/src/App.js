import TopMenu from "./components/TopMenu";
import {BrowserRouter as Router, Redirect, Route, Switch} from "react-router-dom";
import ContactUs from "./components/ContactUs";
import Products from "./components/products/products";
import LandingPage from "./components/LandingPage";
import Notfound from "./components/NotFound";
import NewProduct from "./components/products/NewProduct";
import Login from "./components/auth/Login";
import Register from "./components/auth/Register";
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
function App() {
  return (
    <Router>
    <div className="App">
    
      <TopMenu />
      <ToastContainer />
      <Switch>
        <Route path="/products" exact component={Products}/>
        <Route path="/products/new" exact component={NewProduct}/>
        <Route path="/ContactUs" exact component={ContactUs}/>
        <Route path="/login" exact component={Login}/>
        <Route path="/register" exact component={Register}/>
        <Route path="/NotFound"  component={Notfound}/>
        <Route path="/" component={LandingPage}/>

        <Redirect to="/NotFound"/>
        
      </Switch>
    </div>
    </Router>
  );
}

export default App;
