import Products from "../components/products/products";
import GenericService from "./GenericService";

class ProductService extends GenericService{
    constructor(){
        super();
    }
    addProduct = (data)=> this.post("matches",data);   
    deleteProduct = (_id)=> this.delete("matches/"+ _id);    
    updateProduct = (_id,data)=> this.put("matches/"+ _id,data);
    getProducts = () => this.get("products");

}
let productService  = new ProductService;
export default productService;