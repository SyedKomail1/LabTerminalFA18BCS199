import React from 'react';
import Button from '@material-ui/core/Button';
import TextField from '@material-ui/core/TextField';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import DialogTitle from '@material-ui/core/DialogTitle';
import EditTwoToneIcon from '@material-ui/icons/EditTwoTone';
import { makeStyles } from '@material-ui/core';
import productService from '../services/ProductService';


const useStyles = makeStyles((theme)=>(
    {
      icon: {
          position:"relative",
          bottom:theme.spacing(1),
          marginLeft:"3px",
          cursor:"pointer",
          
      },
      inline:{
          display:"inline",
      }
    }));
export default function UpdateForm({product,onDelete}) {
  const [open, setOpen] = React.useState(false);
  const classes = useStyles();
  const [name,setName] = React.useState(product.name);
  const [text,setText] = React.useState();
  const [price,setPrice] = React.useState(product.price);



  const handleClickOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };
  const handleUpdate = () => {
    productService.updateProduct(product._id,{name,price}).then((data =>{
        console.log(data);
        setText("Product Updated")
        onDelete();
        setOpen(false);
    })).catch(err=>{
        setText("Product not Updated")
        console.log(err);
    })
  };

  return (
    <div className={classes.inline}>
        <EditTwoToneIcon className={classes.icon} fontSize="large" htmlColor="#FFC300" onClick={handleClickOpen}/>
      <Dialog open={open} onClose={handleClose} aria-labelledby="form-dialog-title">
        <DialogTitle id="form-dialog-title">Update Product</DialogTitle>
        
        <DialogContent>
        <DialogContentText color="primary" >
            {text}
        </DialogContentText>
          <TextField
            autoFocus
            margin="dense"
            id="name"
            label="Name"
            type="text"
            fullWidth
            value={name}
            onChange={(e)=>{setName(e.target.value)}}
          />
          <TextField
            margin="dense"
            id="price"
            label="price"
            value={price}
            type="text"
            fullWidth
            onChange={(e)=>{setPrice(e.target.value)}}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose} color="primary">
            Cancel
          </Button>
          <Button onClick={handleUpdate} color="primary">
              Update
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
}