import { makeStyles } from '@material-ui/core';
import TextField from '@material-ui/core/TextField';
import Button from '@material-ui/core/Button';

import React from 'react';
import userService from '../../services/UserService';
import { toast } from 'react-toastify';



const useStyles = makeStyles((theme)=>({

    container:{
        display:"flex",
        justifyContent:"center",
        alignItems:"center",
        height:"300px"
    },
    child:{
        width:"400px",
    },
    margin:{
        marginTop:"15px"
    }
}));
const Register = (props) => {
    const [name,setName] = React.useState("");
    const [email,setEmail] = React.useState("");
    const [password,setPassword] = React.useState("");
    const classes = useStyles();
    return ( <div className={classes.container}>
        <div className={classes.child}>

            <TextField label="Name" fullWidth value={name} onChange={(e=>{
                setName(e.target.value);
            })}/> <br />
            <TextField label="Email" fullWidth value={email} onChange={(e=>{
                setEmail(e.target.value);
            })} /> <br />
            <TextField label="Password" type="password" value={password} fullWidth onChange={(e=>{
                setPassword(e.target.value);
            })}/> <br />
            <Button variant="contained" color="primary" className={classes.margin} onClick={(e)=>{
                userService
                .register(name,email,password).then((data)=>{
                    console.log(data);
                    props.history.push("/login");
                }).catch((err)=>{
                    console.log(err);
                    toast.error(err.response.data, {
                        position: toast.POSITION.TOP_RIGHT
                      });
                    
                })
            }}>Register</Button>
        </div>

    </div> );
}
 
export default Register;