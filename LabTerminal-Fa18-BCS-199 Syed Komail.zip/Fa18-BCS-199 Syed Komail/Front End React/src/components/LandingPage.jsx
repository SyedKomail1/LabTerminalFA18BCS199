import React from 'react';
import { Button } from '@material-ui/core'; 
const LandingPage = () => {
    return ( <div>
        <h1>
            LandingPage     
            </h1>
            <Button variant="outlined" color="inherit" onClick={()=>{alert("button clicked")}}>Hi</Button>

    </div> );
}
 
export default LandingPage;