import {AppBar,Toolbar,Typography,Button,IconButton} from '@material-ui/core';
import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import {Link } from 'react-router-dom';
import userService from '../services/UserService';


const useStyles = makeStyles((theme) => ({
    Link: {
      color: "white",
      textDecoration:"none",
      marginRight: theme.spacing(2),
    },
    menuButton: {
      
    },
    title: {
      flexGrow: 1,
    },
  }));

const TopMenu = () => {
    const classes = useStyles();
    return ( 
        <AppBar position="static">
  <Toolbar>
    <Typography variant="h6">
      <Link to="/" className={classes.Link}>Home</Link>
      <Link to="/products" className={classes.Link}>Matches</Link>
      <Link to="/ContactUs" className={classes.Link}>ContactsUs</Link>
      {!userService.isLoggedIn() ? (<span><Link to="/login" className={classes.Link}>Login</Link>
      <Link to="/register" className={classes.Link}>Register</Link></span>): (<Button variant="contained" color="primary" onClick={e=>{userService.logout();
      window.location.href="/";}}>LogOut {userService.getLoggedInUser().name +" " + userService.getLoggedInUser().role}</Button>)}
      
    </Typography>
     
  </Toolbar>
</AppBar>
     );
}
 
export default TopMenu;