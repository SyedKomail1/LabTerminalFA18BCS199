import { Button, Grid, TextField, } from '@material-ui/core';
import axios from 'axios';
import React from 'react';
import productService from '../../services/ProductService';

import { makeStyles } from '@material-ui/core/styles';
import InputLabel from '@material-ui/core/InputLabel';
import MenuItem from '@material-ui/core/MenuItem';
import FormHelperText from '@material-ui/core/FormHelperText';
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';


const useStyles = makeStyles((theme) => ({
    formControl: {
      margin: theme.spacing(1),
      minWidth: 120,
    },
    selectEmpty: {
      marginTop: theme.spacing(2),
    },
    container: {
        display: 'flex',
        flexWrap: 'wrap',
      },
      textField: {
        marginLeft: theme.spacing(1),
        marginRight: theme.spacing(1),
        width: 200,
      },
  }));
  

const NewProduct = (props) => {
    const classes = useStyles();
    const [name,setName] = React.useState("");
    const [price,setPrice] = React.useState();
    console.log(props);
    const [team1, setTeam1] = React.useState('');
    const [team2, setTeam2] = React.useState('');
    const [city, setCity] = React.useState('');
    const [val, setDate] = React.useState('');
    const [error, setError] = React.useState('');

  const handleChangeTeam1 = (event) => {
    setTeam1(event.target.value);
    console.log(team1);
  };
  const handleError = (event) => {
    setTeam1(event.target.value);
  };
  const handleChangeTeam2 = (event) => {
    setTeam2(event.target.value);
  };
  const handleChangeCity = (event) => {
    setCity(event.target.value);
  };
  const handleChangeDate = (event) => {
    setDate(event.target.value);
    console.log("cc");
  };
    return ( <Grid container spacing={3}>
        <Grid item xs={12}>
            <h1>Add Matches</h1>
            </Grid>
        <Grid item xs={3}></Grid>
        <Grid item xs={6}>
        <h2>{error}</h2>
         <FormControl className={classes.formControl}>
        <InputLabel id="demo-simple-select-helper-label">Select Team</InputLabel>
        <Select
          labelId="demo-simple-select-helper-label"
          id="demo-simple-select-helper"
          value={team1}
          onChange={handleChangeTeam1}
        >
          <MenuItem value="">
          </MenuItem>
          <MenuItem value={"Lahore Qalandars"}>Lahore Qalandars</MenuItem>
          <MenuItem value={"Peshawar Zalmi"}>Quetta Gladiator</MenuItem>
          <MenuItem value={"Multan Sultan"}>Multan Sultan</MenuItem>
          <MenuItem value={"Islamabad United"}>Islamabad United</MenuItem>
          <MenuItem value={"Karachi Kings"}>Karachi Kings</MenuItem>
        </Select>
        <FormHelperText>Some important helper text</FormHelperText>
      </FormControl>

      <FormControl className={classes.formControl}>
        <Select
          labelId="demo-simple-select-helper-label"
          id="demo-simple-select-helper"
          value={team2}
          onChange={handleChangeTeam2}
        >
          <MenuItem value="">
          </MenuItem>
          <MenuItem value={"Lahore Qalandars"}>Lahore Qalandars</MenuItem>
          <MenuItem value={"Peshawar Zalmi"}>Quetta Gladiator</MenuItem>
          <MenuItem value={"Multan Sultan"}>Multan Sultan</MenuItem>
          <MenuItem value={"Islamabad United"}>Islamabad United</MenuItem>
          <MenuItem value={"Karachi Kings"}>Karachi Kings</MenuItem>
        </Select>
        <FormHelperText>Some important helper text</FormHelperText>
      </FormControl>
      <FormControl className={classes.formControl}>
        <InputLabel id="demo-simple-select-helper-label">Select City</InputLabel>
        <Select
          labelId="demo-simple-select-helper-label"
          id="demo-simple-select-helper"
          value={city}
          onChange={handleChangeCity}
        >
          <MenuItem value="">
          </MenuItem>
          <MenuItem value={"Abu Dhabi"}>Abu Dhabi</MenuItem>
          <MenuItem value={"Karachi"}>Karachi</MenuItem>
          <MenuItem value={"Karachi"}>Karachi</MenuItem>
          <MenuItem value={"Islambad"}>Islambad</MenuItem>
          <MenuItem value={"Dubai"}>Dubai</MenuItem>
          <MenuItem value={"Sharjah"}>Sharjah</MenuItem>
        </Select>
        <FormHelperText>Some important helper text</FormHelperText>
      </FormControl>
      <form className={classes.container} noValidate>
      <TextField
        id="datetime-local"
        label="Next appointment"
        type="datetime-local"
        defaultValue="2017-05-24T10:30"
        className={classes.textField}
        value={val}
        onChange={handleChangeDate}
        InputLabelProps={{
          shrink: true,
        }}
      />
    </form>
        </Grid>
        <Grid item xs={3}></Grid>
        <Grid item xs={3}></Grid>
        <Grid item xs ={9}>
        <Button variant="outlined" color="primary" onClick={(e)=>{  
            if(team1===team2){
                setError("plz select differnt teams");
            }else{
                setError("");
                productService.addProduct({team1,team2,city,val}).then((data)=>{
                    props.history.push("/products");
                }).catch((err)=>{
                    console.log(err);
                })
            }
            
        }}>Add Product</Button>
        </Grid>
    </Grid> );
}
 
export default NewProduct;


