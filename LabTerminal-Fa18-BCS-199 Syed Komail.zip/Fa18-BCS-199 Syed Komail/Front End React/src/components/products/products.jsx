import { Fab, Grid, makeStyles } from "@material-ui/core";
import axios from "axios";
import React from "react";
import SingleProduct from "./SingleProduct";
import AddIcon from '@material-ui/icons/Add';
import productService from "../../services/ProductService";
import userService from "../../services/UserService";

const useStyles = makeStyles((theme)=>(
  {
    root: {
      '& > *':{
        margin: theme.spacing(1),
      },
    },
    extendedIcon:{
      marginRight: theme.spacing(1),
      
    },
    addBtn:{
      position:"relative",
      marginTop:"5px",
      float:"right",
      // bottom:theme.spacing(2),
      // right:theme.spacing(2),
    }

  }
))
const Products = (props) => {
  const [products, setProducts ] = React.useState([]);
  const classes = useStyles();

  const getData = ()=>{
    productService.getProducts().then((data)=>{
      setProducts(data.products);
    }).catch((err)=>{
      console.log(err);
    })
  }
  React.useEffect(getData,[]);
  const handleNewProductClick= () =>{
    console.log(props);
    props.history.push("/products/new");
  }
  return (
    <div>
      <h1>Matches </h1>
      
      {products.length ==0? (<p> there are no products</p>):(
        <Grid container spacing={3}>
        {products.map((product,index)=>(
        <SingleProduct key={index} product={product} onDelete={getData}/>
        ))}
        </Grid>
      )}
      {userService.isLoggedIn() && (<Fab color="primary" aria-label="add" variant="extended" className={classes.addBtn} onClick={handleNewProductClick}>
        <AddIcon className={classes.extendedIcon}/> Add Product
      </Fab>)}
      
      
    </div>
  );
};

export default Products;
