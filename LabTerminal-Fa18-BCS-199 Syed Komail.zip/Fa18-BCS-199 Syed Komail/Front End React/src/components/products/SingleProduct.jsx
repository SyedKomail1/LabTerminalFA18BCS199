import { Grid, makeStyles } from '@material-ui/core';
import React from 'react';

import DeleteForeverTwoToneIcon from '@material-ui/icons/DeleteForeverTwoTone';
import productService from '../../services/ProductService';
import UpdateForm from '../UpdateForm';
import userService from '../../services/UserService';

const useStyles = makeStyles((theme)=>(
    {
      icon: {
          position:"relative",
          bottom:theme.spacing(1),
          marginLeft:"3px",
          cursor:"pointer",
          
      },
      left:{
          direction:"rtl",
      },
      inline:{
          display:"inline",
      }
        
    }));
const SingleProduct = ({product,onDelete}) => {
    const classes = useStyles();

    return ( <Grid item xs={3}>
        <div className={classes.inline}>
        <h2>
            {product.name}
        </h2>
        <p>
            {product.price}
        </p>
        </div>
        {userService.isAdmin() && <>
        <div className={classes.left}>
        <DeleteForeverTwoToneIcon className={classes.icon} fontSize="large" htmlColor="#DD0300" onClick={e=>{
            productService.deleteProduct(product._id).then(data =>{
                console.log(data);
                onDelete();
            }).catch(err =>{
                console.log(err);
            })
        }}/>
        <UpdateForm product={product} onDelete={onDelete}/>
        
        </div>
        </>}
        <hr />
        </Grid> );
}
 
export default SingleProduct;