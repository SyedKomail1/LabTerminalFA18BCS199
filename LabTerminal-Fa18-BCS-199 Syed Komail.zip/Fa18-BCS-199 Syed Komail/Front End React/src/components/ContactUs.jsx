import React from 'react';

// sfc -> stateless functional componets
const ContactUs = () => {
    console.log("abc");
    return ( <div>
        <h1>
            ContactUs
        </h1>
    </div> );
}
 
export default ContactUs;